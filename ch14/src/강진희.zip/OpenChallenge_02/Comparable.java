package OpenChallenge_02;

public interface Comparable {
	 
	
}
