package ex_13;

public class Member {
	String name;
	String id;
	String password;
	int age;
}
