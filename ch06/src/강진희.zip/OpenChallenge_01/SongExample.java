package OpenChallenge_01;

public class SongExample {

	public static void main(String[] args) {
	Song song = new Song("Love of My Life", "Queen", "A Night at the Opera", 1975, 100,
            new String[] { "Freddie Mercury", "Bjorn Ulvaeus", "Stig Anderson" });
     
	song.show();
}

}

