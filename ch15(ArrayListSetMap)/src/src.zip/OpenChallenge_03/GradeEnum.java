package OpenChallenge_03;

public enum GradeEnum {
	부장, 차장, 과장, 대리, 사원;
}