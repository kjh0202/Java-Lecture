package exercise_04;

public interface DataAccessObject {
	public abstract void select();
	public abstract void insert();
	public abstract void update();
	public abstract void delete();
}


