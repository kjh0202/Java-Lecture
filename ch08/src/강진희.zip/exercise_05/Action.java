package exercise_05;

public interface Action {
	void work();
}
