package exercise_03;

public class Cat implements Soundable {

	@Override
	public String sound() {
		return "야옹";
	}

}
