package exercise_03;

public interface Soundable {
	String sound();
}
